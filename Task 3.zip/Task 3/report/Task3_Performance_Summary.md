# Task 3 — Walmart Weekly Sales Prediction

## Objective
Predict Walmart weekly sales using historical sales, store and department identifiers, calendar information, markdowns, and economic indicators.

## Data preparation
The cleaned merged dataset contained 421,570 rows and 16 columns. Calendar features (`Year`, `Month`, `Week`) and historical sales features (`Lag_1`, `Lag_2`, `Lag_4`, `Rolling_Mean_4`) were engineered. Rows without the required historical features were removed, leaving 408,436 rows. The chronological split produced 325,663 training rows and 82,773 test rows (approximately 80/20 by date).

Numeric missing values were handled by median imputation within the preprocessing pipeline. Categorical variables (`Store`, `Dept`, `IsHoliday`, `Type`) were one-hot encoded.

## Test results

| Model | MAE | RMSE | R² |
|---|---:|---:|---:|
| Linear Regression | 1,703.62 | 3,319.16 | 0.9772 |
| Random Forest | 1,431.62 | 3,104.46 | 0.9800 |
| Tuned Random Forest | 1,506.59 | 3,242.77 | 0.9782 |

The original Random Forest has the best recorded test results. It was trained on a reproducible sample of 100,000 rows for computational efficiency; Linear Regression was trained on the full training set. The tuned model was selected using a 20,000-row tuning sample and three-fold `TimeSeriesSplit`.

## Feature importance
The Random Forest feature-importance analysis ranked:
- `Lag_1`: 78.77%
- `Rolling_Mean_4`: 16.53%
- `Lag_4`: 1.97%
- `Week`: 0.73%
- `MarkDown3`: 0.37%

The model relies strongly on recent sales history. These importance scores are relative predictive contributions, not causal effects.

## Interpretation
The original Random Forest achieved MAE 1,431.62, RMSE 3,104.46, and R² 0.9800 on the held-out test period. In this experiment it made smaller errors than Linear Regression and the tuned Random Forest. The tuned model did not outperform the original model.

## Limitations
1. The original Random Forest was trained on a 100,000-row sample, whereas Linear Regression used all training rows; training setups differ.
2. The tuning sample was randomly selected and then sorted by date, so it is not a continuous time block. Validation scores are approximate.
3. Markdown columns are sparse. The tuning process warned that some validation folds had no observed values for Markdown columns, which were skipped in those fits.
4. Lag features rely on earlier observed sales. This evaluation is a rolling one-week-ahead setup where previous actual sales are available; it does not evaluate a long-range forecast without new actual sales.
5. Early records lacking enough historical data were removed.
6. Feature importance indicates predictive usefulness, not causation.
7. Results apply to the held-out period and may not generalize equally to other periods or forecasting settings.

## Conclusion
The original Random Forest was the strongest of the three evaluated configurations in this experiment. Further work could use contiguous date-based validation, evaluate additional forecasting horizons, and investigate the effect of sparse markdown variables.
